package com.java.Basic;
class ObjByMethod
{
	int id;
	String name;
	void display(int id,String name)
	{
		System.out.println(id+" "+name);
	}
}
public class ObjByMethodTest{
	public static void main(String[] args) {
		ObjByMethod m=new ObjByMethod();
		m.id=02;
		m.name="SomeOne";
		m.display(m.id,m.name);
	}

}
