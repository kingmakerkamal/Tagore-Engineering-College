package com.java.Basic;
class ObjByReference
{
	int id;
	String name;
}
public class ObjByReferenceTest {
public static void main(String[] args) {
	ObjByReference r=new ObjByReference();
	r.id=01;
	r.name="SomeName";
	System.out.println(r.id+" "+r.name);
}
}
