package com.java.Basic;

public class ClassName {
	int id;
	String name;
public static void main(String args[])
{
	ClassName c=new ClassName();
	System.out.println(c.id);
	System.out.println(c.name);
}
}
